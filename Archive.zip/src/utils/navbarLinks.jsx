export const navbarLinks = [
  { id: 1, text: 'Home', path: '/' },
  { id: 2, text: 'Products', path: '/products' },
  { id: 3, text: 'About Us', path: '/about' },
  { id: 4, text: 'Contact', path: '/contact' },
];
