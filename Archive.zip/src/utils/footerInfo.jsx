export const contactInfo = [
  { id: 1, text: 'PHONE: Toll Free (123) 456-7890' },
  { id: 2, text: 'EMAIL: mail@ecommerce.com' },
  { id: 4, text: 'ADDRESS: 123 Street Name, City, Egypt' },
  { id: 3, text: 'Mon - Sun / 9:00 AM - 8:00 PM ' },
];

export const myAccount = [
  { id: 1, text: 'About Us' },
  { id: 2, text: 'Returns' },
  { id: 4, text: 'Custom Service' },
  { id: 3, text: 'Terms & Condition' },
];
